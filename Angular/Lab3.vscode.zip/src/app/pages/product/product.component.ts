import { Component } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'], // Ojo: es styleUrls, no styleUrl
})
export class ProductComponent {
  dropdownOpen = false;
  selectedFruit = '';
  fruits = ['Apple', 'Banana', 'Mango', 'Orange'];

  toggleDropdown() {
    this.dropdownOpen = !this.dropdownOpen;
  }

  selectFruit(fruit: string) {
    this.selectedFruit = fruit;
    this.dropdownOpen = false;
  }
}