import { Component } from '@angular/core';

@Component({
  selector: 'app-main',
  imports: [],
  templateUrl: './main.component.html',
  styleUrl: './main.component.css'
})
export default class MainComponent {
  title = 'Productos'; 

  categories = [ 
  {id: 1, name: "2x2", img: "img/2x2.avif"}, 
  {id: 2, name: "3x3", img: "img/3x3.avif"}, 
  {id: 3, name: "Pyraminx", img: "img/pyraminx.avif"}, 
  {id: 4, name: "Megaminx", img: "img/megaminx.avif"}, 
  ]
  products = [ 
  {id: 1, name: "Qiyi 2x2", type: "stickered", price: 4.50, img: "img/Qiyi2x2Stickered.webp"}, 
  {id: 2, name: "Qiyi 3x3", type: "stickered", price: 3.50, img: "img/Qiyi3x3Stickered.webp"}, 
  {id: 3, name: "Qiyi Pyraminx", type: "stickerless", price: 7.50, img: "img/QiyiPyraminxStickerless.webp"}, 
  {id: 4, name: "Qiheng Megaminx", type: "stickerless", price: 11.0, img: "img/QihengMegaminxStickerless.webp"}, 
  {id: 5, name: "Moyu 2x2", type: "stickerless", price: 4.65, img: "img/Moyu2x2Stickerless.webp"}, 
  {id: 6, name: "Moyu 3x3", type: "stickerless", price: 4.25, img: "img/Moyu3x3Stickerless.webp"}, 
  {id: 7, name: "Moyu Pyraminx", type: "stickerless", price: 7.75, img: "img/MoyuPyraminxStickerless.webp"}, 
  {id: 8, name: "YJMGC Megaminx", type: "stickerless", price: 11.0, img: "img/YJMGCMegaminxStickerless.webp"},
  ]
}
