export const environment = {
  production: false,
  debugMode: true,
  baseUrl: "http://localhost:8080/api/product",
  fakeUrl: "https://fakestoreapi.com/products/categories"
};
