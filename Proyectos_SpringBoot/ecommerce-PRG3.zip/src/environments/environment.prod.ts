export const environment = {
  production: true,
  debugMode: false,
  baseUrl: "http://localhost:8080/api/product",
  fakeUrl: "https://fakestoreapi.com/products/categories"
};
