import { Component, HostListener, signal } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-header',
  imports: [RouterLink],
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
  isOpen = false;
  isLoggedIn = signal(false)

  toggleMenu() {
    this.isOpen = !this.isOpen;
  }

  scrollPercent = 0;
  scrollY = signal(0);

  ngOnInit(): void {
    this.updateScrollProgress(); // Inicial
  }

  @HostListener('window:scroll', [])
  onScroll(): void {
    this.updateScrollProgress();
    this.scrollY.set(window.scrollY);
  }

  private updateScrollProgress(): void {
    const scrollTop = window.scrollY || document.documentElement.scrollTop;
    const docHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    this.scrollPercent = docHeight ? (scrollTop / docHeight) * 100 : 0;
  }

  get navbarClasses(): string {
    const baseClasses = 'flex justify-around py-4 w-full fixed top-0 left-0 right-0 z-10 backdrop-blur-md transition-colors duration-500';
    const background = this.scrollY() > 10 ? 'bg-white/10' : 'bg-transparent';
    return `${baseClasses} ${background};`
  }
}
