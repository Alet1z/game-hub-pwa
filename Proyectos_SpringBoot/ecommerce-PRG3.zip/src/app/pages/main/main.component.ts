import { TitleCasePipe } from '@angular/common';
import { Component, inject, OnInit } from '@angular/core';
import { Product } from '../../interfaces/interfaces';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-main',
  imports: [TitleCasePipe],
  templateUrl: './main.component.html',
  styleUrl: './main.component.css'
})
export default class MainComponent implements OnInit {
  private apiService = inject(ApiService)

  title = 'Productos';
  categories: any = []
  products: Product[] = []

  ngOnInit(){
    this.loadCategories()
    this.loadProducts()
  }

  loadCategories() {
    this.apiService.getCategories().subscribe({
      next: (res: any) => {
        this.categories = res
      },
      error: (err) => {
        console.warn(err);
      },
    })
  }

  loadProducts() {
    this.apiService.getAllProducts().subscribe({
      next: (res: any) => {
        this.products = res
      },
      error: (err) => {
        console.warn(err);
      },
    })
  }
}
