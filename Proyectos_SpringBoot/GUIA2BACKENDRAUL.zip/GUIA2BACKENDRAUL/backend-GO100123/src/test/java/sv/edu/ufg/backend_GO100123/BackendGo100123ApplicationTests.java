package sv.edu.ufg.backend_GO100123;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendGo100123ApplicationTests {

	@Test
	void contextLoads() {
	}

}
