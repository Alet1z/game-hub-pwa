package sv.edu.ufg.backend_GO100123;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackendGo100123Application {

	public static void main(String[] args) {
		SpringApplication.run(BackendGo100123Application.class, args);
	}

}
